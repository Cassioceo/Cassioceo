alert('Olá mundo \n Agora que já apresentei me lá no github\n Vamos jogar')
let interesse = 'Novidades'
let aprendendo = 'Programação'
let contato = 'cassiorcr@hotmail.com'
alert('Para ganhar preencha todos os campos')
let chuteinteresse = prompt('Qual o interesse do @cassioceo?')
let chuteaprendendo = prompt('O que @cassioceo esta aprendendo')
let chutecontato = prompt ('Qual o email de @cassioceo')
if(chuteinteresse == interesse){

} if(chuteaprendendo == aprendendo){

} if(chutecontato == contato){
    alert('https://www.youtube.com/watch?v=NAmBBzrD2vc')
  } else{
      alert('https://www.youtube.com/watch?v=2c4hnA8jXwo')
  }