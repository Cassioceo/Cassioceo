let jogador = prompt ('Qual é o seu nome?')
let convidado = ['Juliana','juliana','Cinthia','cinthia','Matheus','matheus','Yuri','yuri']

if (jogador == convidado[0]){
    alert('Não pode trapacear, jujuba :)');
} 

if (jogador == convidado[1]){
    alert('Não pode trapacear, jujuba :) por deus escreva seu nome com letra maíuscula');
} 

if (jogador == convidado[2]){
    alert('Boa sorte, espero que ganhe de primeira)');
} 

if (jogador == convidado[3]){
    alert('Boa sorte, espero que ganhe e escreva seu nome com letra maíuscula');
} 

if (jogador == convidado[4]){
    alert('Durante o projeto esqueci que seu nome tem o H');
} 

if (jogador == convidado[5]){
    alert('Durante o projeto esqueci que seu nome tem o H');
} 

if (jogador == convidado[6]){
    alert('Não sei fazer jogos.... lamento desaponta lo');
} 

if (jogador == convidado[7]){
    alert('Não sei fazer jogos... lamento desaponta lo');
} 

let listaDeNumerosSorteados = [];
let numeroLimite = 10
let numeroSecreto = gerarNumeroAleatorio();
let tentativas = 1;

//let titulo = document.querySelector('h1');
//titulo.innerHTML = 'jogo do número secreto';

//let paragrafo = document.querySelector('p');
//paragrafo.innerHTML = 'escolha um número entre 1 e 10';

function exibirTextoNaTela(tag, texto) {
let campo = document.querySelector(tag);
campo.innerHTML = texto;
if('speechSynthesis' in window){
    let utterance = new SpeechSynthesisUtterance(texto);
    utterance.lang = 'pt-BR';
    utterance.rate = 1.2;
    window.speechSynthesis.speak(utterance);
} else {
    console.log("web Speech API não suportada neste navegador.");
    }
}


function exibirMensagemInicial(){
    exibirTextoNaTela ('h1', 'Jogo do número secreto');
    exibirTextoNaTela ('p', 'Escolha um número entre 1 a 10');
      
}
exibirTextoNaTela ('h1', 'Jogo do número secreto');
exibirTextoNaTela ('p', 'Escolha um número entre 1 a 10');

function verificarChute() {
    let chute = document.querySelector('input').value;
    console.log (chute == numeroSecreto);
    if (chute == numeroSecreto){
        exibirTextoNaTela('h1','Acertou');
        let palavraTentativas = tentativas > 1? 'tentativas':'tentativa';
                let mensagemTentativas = `${jogador} ganhou o jogo com ${tentativas} ${palavraTentativas}`;
        exibirTextoNaTela('p',mensagemTentativas);
        document.getElementById('reiniciar').removeAttribute('disabled');

    }else{
        if(chute >numeroSecreto){
            exibirTextoNaTela ('p','O número secreto é menor');
        }else{
            exibirTextoNaTela('p','O número secreto é maior');
        }
        tentativas++;
        limparCampo();
    }
}

function gerarNumeroAleatorio() {
    let numeroEscolhido = parseInt(Math.random() * numeroLimite + 1);
    let quantidadeDeElementosNaLista = listaDeNumerosSorteados.length;
    
    if (quantidadeDeElementosNaLista == numeroLimite){
        listaDeNumerosSorteados = [];
    }

    if (listaDeNumerosSorteados.includes(numeroEscolhido)){
    return gerarNumeroAleatorio ();
    } else {
        listaDeNumerosSorteados.push(numeroEscolhido)
        return numeroEscolhido;
        console.log
    } 
}

function limparCampo() {
    chute = document.querySelector('input');
    chute.value = '';
    }

    function reiniciarJogo(){
        numeroSecreto = gerarNumeroAleatorio();
        limparCampo();
        tentativas = 1;
        exibirMensagemInicial();
        document.getElementById('reiniciar').setAttribute('disabled',true)

    }